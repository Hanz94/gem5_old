// stdafx.h : include file for standard system include files,
// or project specific include files that are used frequently, but
// are changed infrequently
//

#pragma once
#define _CRT_SECURE_NO_WARNINGS

#include <cstdio>
//#include <tchar.h>
#include <cstdlib>
#include <climits>
#include <limits>
#include <ctime>
#include <cmath>
#include <algorithm>
#include <iostream>
#include <fstream>
#include <string>
#include <vector>
#include <queue>
#include <list>


#define DBL_MAX 1.7976931348623158e+308
#define MAX_LENGTH 1024
#define TOTAL_CONFIG_CNT 72
#define ENERGY_UNIT_SCALE 0.1
#define TIME_UNIT_SCALE 0.001
//typedef unsigned long long ullong;

using namespace std;

// TODO: reference additional headers your program requires here
