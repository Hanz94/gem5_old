##################################################################
# Master script to expolore DCR + NoC
# Used to generate results for ESWEEK Paper
# 
# Authors: Nikhil Venkatesh, Subodha Charles
# 02/01/2018
##################################################################

import subprocess
import os
import locale

##################################################################
# Defining some global variables
##################################################################

L1I_CACHE_CONFIG_SPACE = {'l1i_size':['8kB','16kB','32kB'],'l1i_assoc':[1,2,4]}
#L1I_CACHE_CONFIG_SPACE = {'l1i_size':['8kB'],'l1i_assoc':[1]}
L1D_CACHE_CONFIG_SPACE = {'l1d_size':['8kB','16kB','32kB'],'l1d_assoc':[1,2,4]}
#L1D_CACHE_CONFIG_SPACE = {'l1d_size':['8kB'],'l1d_assoc':[1]}
#L2_CACHE_CONFIG_SPACE = {'l2_size':[8192,16384,32768],'l2_assoc':[4,8,16]}
#L2_CACHE_CONFIG_SPACE = {'l2_size':[65536,131072,262144],'l2_assoc':[4,8,16]}
L2_CACHE_CONFIG_SPACE = {'l2_size':[32768, 65536,131072,262144],'l2_assoc':[1,2]}

#BENCHMARKS = ['OCEAN', 'WATER-NSQUARED']
BENCHMARKS = ['FFT','RADIX','FMM','LU']

CACHE_CONFIGS = []

#Paths to files
GEM5_INPUT_FILE_DIR = "/home/eslab/" #used to give L2 Cache config inputs to gem5
GEM5_ROOT = '/home/eslab/garnet-gem5/'
MCPAT_ROOT = '/home/eslab/garnet-gem5/tools/mcpat/'
GEM5_OUT_PARENT = '/home/eslab/garnet-gem5/m5out/ESWEEK/run5/'
GEM5_BENCHMARKS_DIR = '/home/eslab/m5thread-gem5/programs/'
PARSER_DIR = '/home/eslab/garnet-gem5/tools/parsers/'

##################################################################
# function definitions to make life easier
##################################################################

#initialize configurations and write to appropriate files
def initConfigs():
	getExhaustiveHeuristic()

def runTests():
	configCount = 1;
	for cacheConfig in CACHE_CONFIGS:
		bmarkCount = 1;

		for benchmark in BENCHMARKS:
			print "Running Config " + str(configCount) + " out of " + str(len(CACHE_CONFIGS)) + ": " + str(cacheConfig) \
					+ " on benchmark " + str(bmarkCount) + " out of " + str(len(BENCHMARKS)) + ": " + benchmark
			
			#construct the output path with benchmark and cache config
			outPath = GEM5_OUT_PARENT + str(benchmark) +"/"+ str(parse(cacheConfig))
			
			#L2 configs written to separate file since gem5 reads it from there
			writeL2ConfigsToFile([str(cacheConfig['l2_size']), str(cacheConfig['l2_assoc']),str(6)],outPath)			

			executeGem5(cacheConfig, benchmark, outPath)
			parseGEM5Results(outPath, cacheConfig)
			executeMcPAT(outPath)
			parseMCPATResults(outPath)

			bmarkCount=bmarkCount+1
		configCount=configCount+1
		
#Im using a separate file to give inputs to the MCDRAM aka L2 Cache
#L2 Cache configs need to be written to that before running gem5
#Writing another file to gem5 out folder to keep records
def writeL2ConfigsToFile(l2Configs, outPath):
	print "\t Writing L2 Configs:" + str(l2Configs) + " to Gem5 input file..."

	l2ConfigPath = outPath + "/l2Config.cfg"
	
	#if directory already not there, create it
	if not os.path.exists(os.path.dirname(l2ConfigPath)):
		try:
			os.makedirs(os.path.dirname(l2ConfigPath))
		except OSError as exc: # Guard against race condition
			if exc.errno != errno.EEXIST:
				raise

	fh = open(GEM5_INPUT_FILE_DIR + "test.log", "w")
	fc = open(l2ConfigPath, "w")

	for element in l2Configs:
		fh.write(element+"\n")
		fc.write(element+"\n")

	fh.close()
	fc.close()

	print "\t L2 Configs written succesfully\n"

#Execute gem with given cacheConfig and Benchmark
def executeGem5(cacheConfig, benchmark, outPath):
	print "\t Running gem5 on given config..."
	gem5Cmd = GEM5_ROOT+'build/X86/gem5.fast -d ' + outPath + \
			  ' '+GEM5_ROOT+'configs/example/se.py' + \
			  ' --num-cpus=32 --num-dir=32 --cpu-type=timing --cpu-clock=1.4GHz --caches' + \
			  ' --l1d_size=' + str(cacheConfig['l1d_size']) + \
			  ' --l1d_assoc=' + str(cacheConfig['l1d_assoc']) + \
			  ' --l1i_size=' + str(cacheConfig['l1i_size']) + \
			  ' --l1i_assoc=' + str(cacheConfig['l1i_assoc']) + \
			  ' --mem-type=RubyMemoryControl --mem-size=4GB' + \
			  ' --ruby --topology=Mesh_XY --mesh-rows=8 --network=garnet2.0' + \
     		  ' -c ' + GEM5_BENCHMARKS_DIR + benchmark
	print gem5Cmd
	os.system(gem5Cmd)	

#/home/subodha/garnet-gem5/build/X86/gem5.opt -d $OUT_PATH /home/subodha/garnet-gem5/configs/example/se.py --num-cpus=32 --num-dir=32 --cpu-type=timing --cpu-clock=2GHz --caches --l1d_size=32kB --l1i_size=32kB --mem-type=RubyMemoryControl --mem-size=4GB --ruby --topology=Mesh_XY --mesh-rows=8 --network=garnet2.0 -c "/home/subodha/m5thread-gem5/programs/FFT"

#TO DO: execute mcpat with generated xml file
def executeMcPAT(outPath):
	print "\t Running mcpat on given config..."

	mcpatCMD = MCPAT_ROOT + "mcpat -infile " + outPath + "/Xeon.xml >> " + outPath + "/mcpat_out.log"
	print mcpatCMD
	os.system(mcpatCMD)

	print "\t mcpat run complete\n"

#TO DO: gem5 to mcpat parser is invoked here
def	parseGEM5Results(outPath,cacheConfig):
	print "\t Parsing gem5 output File at" + outPath
	#complete path for stats.txt file would be outPath+stats.txt

	createParam(outPath,cacheConfig)
	parserCMD = "python " + PARSER_DIR + "gem5-mcpat-parser.py " + outPath + "/stats.txt " + outPath + "/Xeon.xml " + outPath + "/parameters.txt"
	os.system(parserCMD)
	
	print "\t gem5 output parsed\n"

#TO DO: mcpat results parser invoked here
def	parseMCPATResults(outPath):
	print "\t Parsing mcpat output File"

	mcpatCMD = "python " + PARSER_DIR + "mcpat-csv-parser.py " + outPath + "/mcpat_out.log " + PARSER_DIR + "/modelcsv.csv " + outPath + "/energy.csv"

	os.system(mcpatCMD)

	print "\t mcpat output parsed\n"

#converts string of kb to string of bytes	
def kbtobyte(kb):
	return str(int(kb[:-2])*1024)

#parameter hardcoded values as well as cacheconfig values
def	createParam(gem5OutPath,cacheConfig):
	f= open(gem5OutPath+"/parameters.txt","w+")
	f.write("number_of_cores : 32\n")
	f.write("number_of_L1Directories : 32\n")
	f.write("target_core_clockrate : 1400\n")
	f.write("clock_rate : 1400\n\n")
	f.write("icache_config_capacity : %s\n" % kbtobyte(cacheConfig['l1i_size']))
	f.write("icache_config_block_width : 64\n")
	f.write("icache_config_associativity : %s\n" % cacheConfig['l1i_assoc'])
	f.write("icache_config_bank : 1\n")
	f.write("icache_config_throughput_wrt_core_clock : 8\n")
	f.write("icache_config_latency_wrt_core_clock : 3\n")
	f.write("icache_config_output_width : 64\n")
	f.write("icache_config_cache policy : 0\n\n")
	
	f.write("dcache_config_capacity : %s\n" % kbtobyte(cacheConfig['l1d_size']))
	f.write("dcache_config_block_width : 64\n")
	f.write("dcache_config_associativity : %s\n" % cacheConfig['l1d_assoc'])
	f.write("dcache_config_bank : 1\n")
	f.write("dcache_config_throughput_wrt_core_clock : 3\n")
	f.write("dcache_config_latency_wrt_core_clock : 3\n")
	f.write("dcache_config_output_width : 64\n")
	f.write("dcache_config_cache policy : 1\n\n")	

	f.write("L2cache_config_capacity : %s\n" % cacheConfig['l2_size'])
	f.write("L2cache_config_block_width : 64\n")
	f.write("L2cache_config_associativity : %s\n" % cacheConfig['l2_assoc'])
	f.write("L2cache_config_bank : 8\n")
	f.write("L2cache_config_throughput_wrt_core_clock : 8\n")
	f.write("L2cache_config_latency_wrt_core_clock : 8\n")
	f.write("L2cache_config_output_width : 64\n")
	f.write("L2cache_config_cache policy : 1\n\n")
	
	f.write("NoC0_horizontal_nodes : 8\n")
	f.write("NoC0_vertical_nodes : 4\n\n")
	
	f.write("core_tech_node : 65\n")
	f.write("number_mcs : 8\n")
	#print cacheConfig

#convert a dictionary to a string to use as a file name
def parse(config):
	parsedConfig = str(config['l1i_size']) + "_" + \
   				   str(config['l1i_assoc']) + "_" + \
   				   str(config['l1d_size']) + "_" + \
   				   str(config['l1d_assoc'])+ "_" + \
   				   str(config['l2_size']/1024) + "kB_" + \
   				   str(config['l2_assoc'])
	
	return parsedConfig

#convert a size string to int
def toInt(size):
	if type(size) is not str:
		return size/1024
	else:
		return int(size.strip("kB"))

#given the cache config space, populate a list of all possible
#cache configs depending on reconfigurable cache architecture
#ref: \cite{wang2009dynamic} Section 3.1
def getPossibleCacheConfigs(CACHE_CONFIG_SPACE, bankSize):

	keys = []
	for key in CACHE_CONFIG_SPACE:
		keys.append(key)
	sizes = CACHE_CONFIG_SPACE[keys[0]]

	assocs = CACHE_CONFIG_SPACE[keys[1]]
	minAssoc = min(assocs)
	assocs = [assoc/minAssoc for assoc in assocs]

	'''	
	for size in sizes:
		for assoc in assocs:
			print str(toInt(size)) + " | " + str(assoc) + " | " + str(toInt(size)/assoc)
			if (toInt(size)/assoc)>=bankSize:
				print [size, assoc]
	'''

	config = [[size,assoc*minAssoc] for size in sizes for assoc in assocs if ((toInt(size)/assoc)>=bankSize)]

	#print config
	return config	 

#From the possible cache configs, get ehaustive combinations of L1I, L1D and L2 caches
#Accounts for 6x6x6 = 216 max possiblities in our explorations
def getExhaustiveHeuristic():
	cacheConfig = {}

	L1I_CONFIGS = getPossibleCacheConfigs(L1I_CACHE_CONFIG_SPACE, 8)	
	L1D_CONFIGS = getPossibleCacheConfigs(L1D_CACHE_CONFIG_SPACE, 8)
	L2_CONFIGS = getPossibleCacheConfigs(L2_CACHE_CONFIG_SPACE, 16)

	for l1iConfig in L1I_CONFIGS:
		for l1dConfig in L1D_CONFIGS:
			for l2Config in L2_CONFIGS:
				cacheConfig['l1i_size'] = l1iConfig[0]
				cacheConfig['l1i_assoc'] = l1iConfig[1]
				cacheConfig['l1d_size'] = l1dConfig[0]
				cacheConfig['l1d_assoc'] = l1dConfig[1]
				cacheConfig['l2_size'] = l2Config[0]
				cacheConfig['l2_assoc'] = l2Config[1]
				
				CACHE_CONFIGS.append(cacheConfig.copy())
	'''

	cacheConfig['l1i_size'] = L1I_CACHE_CONFIG_SPACE['l1i_size'][0]
	cacheConfig['l1i_assoc'] = L1I_CACHE_CONFIG_SPACE['l1i_assoc'][0]
	cacheConfig['l1d_size'] = L1D_CACHE_CONFIG_SPACE['l1d_size'][0]
	cacheConfig['l1d_assoc'] = L1D_CACHE_CONFIG_SPACE['l1d_assoc'][0]
	cacheConfig['l2_size'] = L2_CACHE_CONFIG_SPACE['l2_size'][0]
	cacheConfig['l2_assoc'] = L2_CACHE_CONFIG_SPACE['l2_assoc'][0]

	CACHE_CONFIGS.append(cacheConfig.copy())
	
	cacheConfig['l1i_size'] = L1I_CACHE_CONFIG_SPACE['l1i_size'][1]
	cacheConfig['l1i_assoc'] = L1I_CACHE_CONFIG_SPACE['l1i_assoc'][1]
	cacheConfig['l1d_size'] = L1D_CACHE_CONFIG_SPACE['l1d_size'][1]
	cacheConfig['l1d_assoc'] = L1D_CACHE_CONFIG_SPACE['l1d_assoc'][1]
	cacheConfig['l2_size'] = L2_CACHE_CONFIG_SPACE['l2_size'][1]
	cacheConfig['l2_assoc'] = L2_CACHE_CONFIG_SPACE['l2_assoc'][1]

	CACHE_CONFIGS.append(cacheConfig.copy())	

	cacheConfig['l1i_size'] = L1I_CACHE_CONFIG_SPACE['l1i_size'][2]
	cacheConfig['l1i_assoc'] = L1I_CACHE_CONFIG_SPACE['l1i_assoc'][2]
	cacheConfig['l1d_size'] = L1D_CACHE_CONFIG_SPACE['l1d_size'][2]
	cacheConfig['l1d_assoc'] = L1D_CACHE_CONFIG_SPACE['l1d_assoc'][2]
	cacheConfig['l2_size'] = L2_CACHE_CONFIG_SPACE['l2_size'][2]
	cacheConfig['l2_assoc'] = L2_CACHE_CONFIG_SPACE['l2_assoc'][2]

	CACHE_CONFIGS.append(cacheConfig.copy())	

	print len(CACHE_CONFIGS)
	'''
##################################################################
# let's run it now, shall we?
##################################################################
initConfigs()
runTests()

print "My work is done here....."
